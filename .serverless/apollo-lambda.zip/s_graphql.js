var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ygutfreund',
applicationName: 'awsapollo',
appUid: 'hGwhKwj4PcBV3MYxHT',
tenantUid: 'y4jQk0ckJQNBvJ544j',
deploymentUid: 'ccca479e-7f3c-4c13-a92d-be54e4571624',
serviceName: 'apollo-lambda',
stageName: 'dev',
pluginVersion: '3.2.3'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6}
try {
  const userHandler = require('./server.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
